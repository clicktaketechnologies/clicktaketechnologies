# ClickTake Technologies — Website

Next.js 16 (App Router) + TypeScript + Tailwind v4 + shadcn/ui.

## Quick start

```bash
# 1. Install dependencies
npm install        # or: bun install

# 2. Create .env.local with:
#    DATABASE_URL="file:./db/custom.db"
#    (plus RESEND_API_KEY, TURNSTILE_SECRET_KEY, TURNSTILE_SITE_KEY if you wire them up)

# 3. Run the dev server
npm run dev        # or: bun dev
```

Visit http://localhost:3000

## Production

```bash
npm run build
npm start
```

## Brand

- Primary: #136DFF
- Accent:  #FF53A9
- Domain:  www.clicktaketech.com
- Email:   Info@clicktaketech.com
- Phones:  +923069753003 (PK) / +447391653377 (UK)
- Locations: UK (Birmingham), Pakistan, USA, Dubai

## Structure

- `src/app/` — Next.js App Router pages & API routes
- `src/components/site/` — ClickTake site components (Navbar, Hero, Services, etc.)
- `src/components/ui/` — shadcn/ui primitives
- `src/lib/` — site-data, db, mailer, turnstile, utils
- `public/` — logo + images
- `prisma/schema.prisma` — DB schema (User, Post, ContactMessage)

## Features

- Multi-region SEO content (UK / Pakistan / USA / Dubai)
- Background canvas animation + custom cursor + Three.js hero
- Light/dark theme toggle (next-themes, FOUC-safe)
- Mega menu with all service categories
- Contact form API route with Turnstile + Prisma + nodemailer
- JSON-LD Organization schema with multi-country address + 8 socials
- sitemap.ts + robots.ts
